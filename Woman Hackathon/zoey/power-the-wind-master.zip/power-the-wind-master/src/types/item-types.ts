export default {
  TURBINE: "turbine"
};
